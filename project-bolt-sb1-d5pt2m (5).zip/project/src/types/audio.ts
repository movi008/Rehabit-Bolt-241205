export interface AudioContextState {
  analyser: AnalyserNode;
  dataArray: Uint8Array;
}