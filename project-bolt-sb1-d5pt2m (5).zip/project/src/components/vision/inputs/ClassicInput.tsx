import React, { useState, useRef } from 'react';
import { 
  Send, 
  Loader2, 
  Mic, 
  Video, 
  Image as ImageIcon, 
  Link, 
  File, 
  Camera,
  Upload,
  X
} from 'lucide-react';
import { VideoRecorder } from './VideoRecorder';

interface ClassicInputProps {
  onSubmit: (text: string) => Promise<void>;
  isSubmitting: boolean;
  initialValue: string;
}

type InputMode = 'text' | 'voice' | 'video-upload' | 'video-record' | 'camera';

export function ClassicInput({ onSubmit, isSubmitting, initialValue }: ClassicInputProps) {
  const [text, setText] = useState(initialValue);
  const [inputMode, setInputMode] = useState<InputMode>('text');
  const [attachments, setAttachments] = useState<File[]>([]);
  const [previewUrls, setPreviewUrls] = useState<string[]>([]);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || isSubmitting) return;
    await onSubmit(text);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setAttachments(prev => [...prev, ...files]);

    const newPreviewUrls = files.map(file => {
      if (file.type.startsWith('image/') || file.type.startsWith('video/')) {
        return URL.createObjectURL(file);
      }
      return '';
    });
    setPreviewUrls(prev => [...prev, ...newPreviewUrls]);
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
    if (previewUrls[index]) {
      URL.revokeObjectURL(previewUrls[index]);
    }
    setPreviewUrls(prev => prev.filter((_, i) => i !== index));
  };

  const handleVideoRecorded = (file: File, previewUrl: string) => {
    setAttachments(prev => [...prev, file]);
    setPreviewUrls(prev => [...prev, previewUrl]);
    setInputMode('text');
  };

  return (
    <div className="space-y-4">
      {/* Input Mode Selector */}
      <div className="flex items-center space-x-2 pb-2 border-b border-gray-200">
        <button
          onClick={() => setInputMode('text')}
          className={`p-2 rounded-lg transition-colors ${
            inputMode === 'text' ? 'bg-[#007dff]/10 text-[#007dff]' : 'text-gray-500 hover:bg-gray-100'
          }`}
        >
          <Send className="w-5 h-5" />
        </button>
        <button
          onClick={() => setInputMode('voice')}
          className={`p-2 rounded-lg transition-colors ${
            inputMode === 'voice' ? 'bg-[#007dff]/10 text-[#007dff]' : 'text-gray-500 hover:bg-gray-100'
          }`}
        >
          <Mic className="w-5 h-5" />
        </button>
        <div className="h-6 w-px bg-gray-200" />
        <button
          onClick={() => setInputMode('video-upload')}
          className={`p-2 rounded-lg transition-colors ${
            inputMode === 'video-upload' ? 'bg-[#007dff]/10 text-[#007dff]' : 'text-gray-500 hover:bg-gray-100'
          }`}
        >
          <Video className="w-5 h-5" />
        </button>
        <button
          onClick={() => setInputMode('video-record')}
          className={`p-2 rounded-lg transition-colors ${
            inputMode === 'video-record' ? 'bg-[#007dff]/10 text-[#007dff]' : 'text-gray-500 hover:bg-gray-100'
          }`}
        >
          <Camera className="w-5 h-5" />
        </button>
        <div className="h-6 w-px bg-gray-200" />
        <button
          onClick={() => fileInputRef.current?.click()}
          className="p-2 rounded-lg text-gray-500 hover:bg-gray-100"
        >
          <File className="w-5 h-5" />
        </button>
        <button
          onClick={() => imageInputRef.current?.click()}
          className="p-2 rounded-lg text-gray-500 hover:bg-gray-100"
        >
          <ImageIcon className="w-5 h-5" />
        </button>
        <button
          onClick={() => {
            const url = prompt('Enter URL:');
            if (url) setText(prev => prev + `\n${url}`);
          }}
          className="p-2 rounded-lg text-gray-500 hover:bg-gray-100"
        >
          <Link className="w-5 h-5" />
        </button>
      </div>

      {/* Video Recording Interface */}
      {inputMode === 'video-record' && (
        <VideoRecorder
          onVideoRecorded={handleVideoRecorded}
          onCancel={() => setInputMode('text')}
        />
      )}

      {/* Video Upload Interface */}
      {inputMode === 'video-upload' && (
        <div className="flex flex-col items-center space-y-4 py-8 border-2 border-dashed border-gray-200 rounded-lg">
          <div className="p-6 rounded-full bg-gray-100">
            <Upload className="w-8 h-8 text-gray-400" />
          </div>
          <div className="text-center">
            <p className="text-gray-900 font-medium">Upload Video</p>
            <p className="text-sm text-gray-500 mt-1">
              Share a video describing your vision
            </p>
          </div>
          <button
            onClick={() => videoInputRef.current?.click()}
            className="flex items-center space-x-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50"
          >
            <Upload className="w-5 h-5 text-gray-400" />
            <span className="text-gray-600">Choose Video</span>
          </button>
        </div>
      )}

      {/* Attachments Preview */}
      {attachments.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {attachments.map((file, index) => (
            <div key={index} className="relative group">
              {file.type.startsWith('video/') ? (
                <video
                  src={previewUrls[index]}
                  className="w-40 h-40 object-cover rounded-lg border border-gray-200"
                />
              ) : previewUrls[index] ? (
                <img
                  src={previewUrls[index]}
                  alt={`Attachment ${index + 1}`}
                  className="w-40 h-40 object-cover rounded-lg border border-gray-200"
                />
              ) : (
                <div className="w-40 h-40 flex items-center justify-center bg-gray-100 rounded-lg border border-gray-200">
                  <File className="w-8 h-8 text-gray-400" />
                </div>
              )}
              <button
                onClick={() => removeAttachment(index)}
                className="absolute -top-2 -right-2 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Text Input and Submit */}
      <form onSubmit={handleSubmit} className="space-y-4">
        {inputMode === 'text' && (
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="In my vision of the future..."
            className="w-full h-48 px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#007dff] focus:border-transparent resize-none"
            disabled={isSubmitting}
          />
        )}

        {/* Hidden File Inputs */}
        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="hidden"
          onChange={handleFileChange}
        />
        <input
          ref={videoInputRef}
          type="file"
          accept="video/*"
          className="hidden"
          onChange={handleFileChange}
        />
        <input
          ref={imageInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileChange}
        />

        <button
          type="submit"
          disabled={!text.trim() || isSubmitting}
          className="w-full sm:w-auto flex items-center justify-center space-x-2 px-6 py-3 bg-[#007dff] text-white rounded-lg hover:bg-[#0066cc] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>Processing...</span>
            </>
          ) : (
            <>
              <Send className="w-5 h-5" />
              <span>Submit Vision</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
}